//
//  MiniDroneVC.h
//  SDKSample
//

#import <UIKit/UIKit.h>
#import <libARDiscovery/ARDISCOVERY_BonjourDiscovery.h>

@interface MiniDroneVC : UIViewController

@property (nonatomic, strong) ARService *service;

@end
